    /*$RCSfile: validateUtilities.js,v $ $Revision: 1.2 $ $Date: 2004/03/28 16:53:21 $ */

  /**
  * This is a place holder for common utilities used across the javascript validation
  *
  **/